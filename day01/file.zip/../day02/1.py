f = open("5.txt", "w")
print(f)



