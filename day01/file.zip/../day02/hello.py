#!/usr/bin/python3

s = "老婆".encode()
print(s)