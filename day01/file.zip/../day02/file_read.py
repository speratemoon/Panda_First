"""
    文件读取示例
"""
f = open("2.txt", "r")
# while True:
#     data = f.read(5)
#     if data == "":
#         break
#     print(data, end="")
# line = f.readline()
# print(line)
line = f.readline(20)
print(line)
# list_ = f.readlines(30)
# print(list_)
# for line in f:
#     print(line)
