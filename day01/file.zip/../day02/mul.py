result = 1

for i in range(1,101):
    result *= i 

print("result = ",result)
